const express = require('express');
const serverless = require('serverless-http');
const app = express();

// Importar seu app.js
const appJS = require('../src/app');

// Usar o middleware de app.js
app.use('/.netlify/functions/server', appJS);

// Exportar a função serverless
module.exports.handler = serverless(app);
