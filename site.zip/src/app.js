const express = require('express');
const app = express();

// Suas rotas e middlewares aqui
app.get('/', (req, res) => {
  res.send('Hello World!');
});

module.exports = app;
